package com.example.home.attendance_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Status extends AppCompatActivity {
TextView percentDisplay;
TextView displaySection;
TextView displayYear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        percentDisplay=(TextView)findViewById(R.id.display1);
        percentDisplay.setText(getIntent().getStringExtra("number"));
        displaySection=(TextView)findViewById(R.id.display3);
        displaySection.setText(getIntent().getStringExtra("class"));
        displayYear=(TextView)findViewById(R.id.display2);
        displayYear.setText(getIntent().getStringExtra("year"));
    }
}
