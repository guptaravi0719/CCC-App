package com.example.home.attendance_app;

import android.content.Intent;
import android.net.Uri;
import android.provider.Telephony;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;


public class Help extends AppCompatActivity {

    public Spinner topic;
    String number;
    String msg;
    String subject;
   EditText message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        topic =(Spinner)findViewById(R.id.topic);
        ArrayAdapter<String> topicList= new ArrayAdapter<String>(Help.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.issue));
        topicList.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        topic.setAdapter(topicList);

 /* button2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            phoneNo="8010110000";
            number="hello";
           SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, number, null, null);
            Toast.makeText(Help.this, "Message Sent",
                    Toast.LENGTH_LONG).show();    }
});*/
 }

    public void send(View view) {
        subject=topic.getSelectedItem().toString();
        message=(EditText)findViewById(R.id.for_report);
        msg=message.getText().toString();
        String message= createsummary2(subject,msg);
        Intent intentf2=new Intent(Intent.ACTION_SENDTO);
        intentf2.setData(Uri.parse("mailto:cloudcomputingcell.helpdesk@gmail.com"));
        intentf2.putExtra(Intent.EXTRA_SUBJECT,"Error Report");
        intentf2.putExtra(Intent.EXTRA_TEXT,message);
        if (intentf2.resolveActivity(getPackageManager())!=null)
        {startActivity(intentf2);
        }

    }
    private String createsummary2(String subject,String msg)
    { String message =" Issue : "+subject;
        message=message+"\n\nDescription : "+msg;

        return message;
    }



}
